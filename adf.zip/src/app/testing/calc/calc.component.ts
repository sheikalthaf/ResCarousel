import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.scss']
})
export class CalcComponent implements OnInit {
  calcForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.calcForm = this.fb.group({
      qty: 0,
      rate: 0,
      tax: 0,
      taxAmt: 0,
      amt: 0
    });

    this.calcForm.get('rate').valueChanges.debounceTime(100).distinctUntilChanged().delay(10).subscribe(() => this.calcMethod());
    this.calcForm.get('qty').valueChanges.debounceTime(100).distinctUntilChanged().delay(10).subscribe(() => this.calcMethod());
    this.calcForm.get('tax').valueChanges.debounceTime(100).distinctUntilChanged().delay(10).subscribe(() => this.calcMethod());
  }

  private calcMethod() {
    const val = this.calcForm.value;
    const taxWithOutQty = val.rate * val.tax / 100;
    const taxWithQty = taxWithOutQty * val.qty;
    const amt = (+val.rate + taxWithOutQty) * val.qty;
    console.log(taxWithQty);
    this.calcForm.patchValue({
      taxAmt: taxWithQty,
      amt: amt
    });
  }

}
