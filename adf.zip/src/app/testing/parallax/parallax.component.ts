import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parallax',
  templateUrl: './parallax.component.html',
  styleUrls: ['./parallax.component.scss']
})
export class ParallaxComponent implements OnInit {
  imageURL: any;

  constructor() { }

  ngOnInit() {

    this.imageURL = 'assets/bg.jpg';
  }



}
