import { Component, OnInit } from '@angular/core';
import { NguAlertService } from '@ngu/alert';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit {
  constructor(private alert: NguAlertService) {}

  ngOnInit() {}

  openAlert() {
    let tim = 0;
    for (let i = 0; i < 20; i++) {
      setTimeout(() => {
        this.alert.open({
          heading: 'This is a heading',
          msg: 'This is a message from alert',
          type: 'success',
          duration: 1000
        });
      }, (tim += 100));
    }
  }
}
