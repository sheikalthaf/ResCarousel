import { Component, OnInit } from '@angular/core';
import { NguCarousel, NguCarouselStore } from './../../@ngu/carousel/ngu-carousel/ngu-carousel.interface';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit {
  slideNum: number;
  dar: string;
  resetCaro = 0;
  carouselBanner: NguCarousel;
  public carouselTileItems: Array<any>;
  public carouselTile: NguCarousel;

  constructor() {}

  ngOnInit() {
    this.carouselBanner = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 400,
      interval: 4000,
      point: {
        visible: true,
        pointStyles: `
          .ngucarouselPoint {
            list-style-type: none;
            text-align: center;
            padding: 12px;
            margin: 0;
            white-space: nowrap;
            overflow: auto;
            position: absolute;
            width: 100%;
            bottom: 20px;
            left: 0;
            box-sizing: border-box;
          }
          .ngucarouselPoint li {
            display: inline-block;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.55);
            padding: 5px;
            margin: 0 3px;
            transition: .4s ease all;
          }
          .ngucarouselPoint li.active {
              background: white;
              width: 10px;
          }
        `
      },
      load: 2,
      loop: true,
      touch: true
    };

    this.carouselTileItems = [
      2111,
      1122,
      1111,
      1122,
      1122,
      1122,
      2111,
      1111,
      1122,
      2122,
      1111,
      1122,
      1122,
      1111
    ];

    this.carouselTile = {
      grid: { xs: 2, sm: 3, md: 3, lg: 5, all: 0 },
      slide: 2,
      speed: 400,
      animation: 'lazy',
      point: {
        visible: true
      },
      load: 2,
      touch: true,
      easing: 'ease'
    };
    this.slideNum = 0;
  }

  /* It will be triggered on every slide*/
  onmoveFn(data: NguCarouselStore) {
    // console.log(data);
  }

  onChangers(e) {
    this.slideNum = 1;
    this.slideNum = 0;
    console.log(this.dar);
    this.resetCaro++;
  }

  public carouselTileLoad(evt: any) {
    const len = this.carouselTileItems.length;
    if (len <= 30) {
      for (let i = len; i < len + 10; i++) {
        // this.carouselTileItems.push(i);
      }
    }
  }
}
