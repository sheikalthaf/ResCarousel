import { Component, OnInit } from '@angular/core';
import { NguModalService } from '../../@ngu/modal/ngu-modal/ngu-modal.service';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
  public sampleText: any;

  constructor(private modal: NguModalService) {}

  ngOnInit() {
    this.sampleText = {
      id: 'sampleTextID'
    };
  }

  openModal() {
    this.modal.open(this.sampleText.id);
  }

  closeModal() {
    this.modal.close(this.sampleText.id);
  }

  beforestartModal() {
    console.log('beforestartModal');
  }

  afterstartModal() {
    console.log('afterstartModal');
  }

  beforeendModal() {
    console.log('beforeendModal');
  }

  afterendModal() {
    console.log('afterendModal');
  }
}
