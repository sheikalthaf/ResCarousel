import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule, AppRoutingComponents } from './app-routing.module';

import { AppComponent } from './app.component';
// import { NguCarouselModule } from '@ngu/carousel';
// import { NguCarouselModule } from '@ngu/carousel';
import { NguAlertModule } from '@ngu/alert';
import { NguParallaxModule } from '@ngu/parallax';
import { NguModalModule } from './@ngu/modal/ngu-modal.module';
import { FilterPipe } from './filter/filter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ModalComponent } from './testing/modal/modal.component';
import { ParallaxComponent } from './testing/parallax/parallax.component';
import { AlertComponent } from './testing/alert/alert.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { CollapseComponent } from './@ngu/collapse/collapse.component';
import { NguCollapseModule } from './@ngu/collapse/collapse.module';
import { NavigationComponent } from './navigation/navigation.component';
import { AccordionComponent } from './testing/accordion/accordion.component';
import { NguCarouselModule } from './@ngu/carousel/ngu-carousel.module';
import { NguAccordionModule } from './@ngu/accordion/accordion.module';

@NgModule({
  declarations: [
    AppComponent,
    FilterPipe,
    ModalComponent,
    ParallaxComponent,
    AlertComponent,
    CollapseComponent,
    NavigationComponent,
    AccordionComponent,
    AppRoutingComponents
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    ServiceWorkerModule.register('/ngsw-worker.js', {
      enabled: environment.production
    }),
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NguCarouselModule,
    NguAlertModule,
    NguModalModule,
    NguParallaxModule,
    NguCollapseModule,
    NguAccordionModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
