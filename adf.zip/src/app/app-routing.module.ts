import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AccordionComponent } from './testing/accordion/accordion.component';
import { CarouselComponent } from './testing/carousel/carousel.component';
import { CalcComponent } from './testing/calc/calc.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: AppComponent
  },
  {
    path: 'carousel',
    component: CarouselComponent
  },
  {
    path: 'accordion',
    component: AccordionComponent
  },
  {
    path: 'calc',
    component: CalcComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const AppRoutingComponents = [CarouselComponent, AccordionComponent, CalcComponent];
