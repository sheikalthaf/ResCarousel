import { Injectable } from '@angular/core';

@Injectable()
export class NguStorageService {
  private storageKey = 'ngu-';
  constructor() {}

  get(key) {
    return this.store(1, key);
  }
  set() {}
  delete() {}
  flush() {}

  private store(type, key, data?) {
    if (type === 1) {
      localStorage.getItem(this.storageKey + key);
    } else if (type === 2) {
      localStorage.setItem(this.storageKey + key, data);
    } else if (type === 3) {
      localStorage.removeItem(this.storageKey + key);
    }
  }

  private flushFn() {
    localStorage.length;
    for (let i = 0; i < localStorage.length; i++) {
      // localStorage[0].se
    }
  }
}
