import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'ngu-acc-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  // @HostListener('click', ['$event'])
  // onClicking($event) {
  //   console.log($event);
  // }

  constructor() {}

  ngOnInit() {}
}
