export interface NguAccData {
  data: any;
}
