import {
  Component,
  OnInit,
  ContentChild,
  ElementRef,
  AfterContentInit,
  Renderer2,
  ViewChild,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import {
  AnimationBuilder,
  AnimationFactory,
  style,
  animate,
  AnimationPlayer
} from '@angular/animations';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'ngu-acc-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.scss']
})
export class BodyComponent implements OnInit, AfterContentInit {
  isAnimating: boolean;
  player: AnimationPlayer;
  id: any;
  child: any;
  childActive = true;
  @ContentChild(HeaderComponent, { read: ElementRef })
  header: ElementRef;
  @Output('clickListner') clickListner: EventEmitter<any> = new EventEmitter();

  @ViewChild('child') child1: ElementRef;

  constructor(private renderer: Renderer2, public builder: AnimationBuilder) {}

  callAccor(aff, bol) {
    if (bol) {
      this.animate(aff);
    } else {
      this.childActive !== aff && this.animate(false);
    }
    this.childActive = aff;
  }

  ngOnInit() {}

  ngAfterContentInit() {
    this.child = this.child1.nativeElement;
    this.renderer.addClass(this.child, 'ani');
    this.renderer.listen(this.header.nativeElement, 'click', () => {
      this.clickListner.emit(this.childActive);
    });
  }

  /**
   * 1 =  is for opening
   * 0 =  is for closing
   */

  animateChilds(id) {
    this.renderer.setAttribute(this.child, 'style', '');
    const hei = this.child.scrollHeight;
    if (!id) {
      // console.log('closing');
      this.renderer.setStyle(this.child, 'height', `${hei}px`);
      setTimeout(() => {
        this.renderer.setStyle(this.child, 'height', `0px`);
        this.renderer.setStyle(this.child, 'transform', `scale(.9)`);
        this.renderer.addClass(this.child, 'activeCollapse');
      }, 10);
    } else {
      // console.log('opening');
      this.renderer.addClass(this.child, 'activeCollapse');
      this.renderer.setStyle(this.child, 'transform', `scale(.5)`);
      setTimeout(() => {
        this.renderer.setStyle(this.child, 'transform', `scale(1)`);
        this.renderer.setStyle(this.child, 'height', `${hei}px`);
      }, 10);
    }
    setTimeout(() => {
      this.renderer.removeClass(this.child, 'activeCollapse');
      this.renderer.setAttribute(this.child, 'style', '');
      this.renderer.addClass(this.child, 'ani');
      if (!id) {
        this.renderer.setStyle(this.child, 'display', 'none');
      }
    }, 300);
  }

  animate(id) {
    let factory: AnimationFactory;
    this.id = id;
    this.renderer.setAttribute(this.child, 'style', '');
    const hei = this.child.scrollHeight;
    console.log(hei);
    if (!id) {
      factory = this.builder.build([
        style({
          width: 'auto',
          display: 'block',
          position: 'relative',
          height: hei,
          transform: 'scale(1)'
        }),
        animate('350ms ease', style({ height: '0px', transform: 'scale(.9)' }))
      ]);
    } else {
      factory = this.builder.build([
        style({
          width: 'auto',
          display: 'block',
          position: 'relative',
          height: '0px',
          transform: 'scale(.9)'
        }),
        animate(
          '350ms cubic-bezier(.35, 0, .25, 1)',
          style({ height: hei + 'px', transform: 'scale(1)'})
        )
      ]);
    }

    // this creates the animation
    this.player = factory.create(this.child);
    // this.player.finish();

    // start it off
    this.player.play();
    this.player.onStart(() => {
      this.isAnimating = true;
    });
    this.player.onDone(() => {
      console.log('completed');
      this.isAnimating = false;
      // this.renderer.setAttribute(this.child, 'style', '');
      this.player.reset();
      if (!id) {
        this.renderer.setStyle(this.child, 'display', 'none');
        // this.renderer.setStyle(this.child, 'height', 'auto');
      } else {
        this.renderer.setStyle(this.child, 'display', 'block');
        // this.renderer.setStyle(this.child, 'height', 'auto');
      }
    });
    console.log('player');
  }
}
