import {
  Component,
  OnInit,
  ContentChildren,
  QueryList,
  AfterContentInit,
  Input
} from '@angular/core';
import { BodyComponent } from '../body/body.component';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'ngu-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent implements OnInit, AfterContentInit {
  @Input('inputs') inputs: boolean;
  @Input('closers') closers: boolean;
  @ContentChildren(BodyComponent) accBody: QueryList<BodyComponent>;

  constructor() {}

  ngOnInit() {
    this.inputs = this.inputs || false;
    this.closers = this.closers || false;
  }

  ngAfterContentInit() {
    this.accBody.forEach((b, i) => {
      this.closers && b.callAccor(false, false);
      b.clickListner.subscribe(res => {
        this.accBody.forEach((c, j) => {
          if (b === c) {
            c.callAccor(!res, true);
          } else {
            this.inputs && c.callAccor(false, false);
          }
        });
      });
    });
  }
}
