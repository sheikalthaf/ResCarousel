import { TestBed, inject } from '@angular/core/testing';

import { NguModalService } from './ngu-modal.service';

describe('ModalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NguModalService]
    });
  });

  it('should be created', inject([NguModalService], (service: NguModalService) => {
    expect(service).toBeTruthy();
  }));
});
