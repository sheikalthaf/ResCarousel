import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NguModalComponent } from './ngu-modal.component';

describe('ModalComponent', () => {
  let component: NguModalComponent;
  let fixture: ComponentFixture<NguModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NguModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NguModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
