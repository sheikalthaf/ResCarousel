export interface NguCollapse {
  collapse: string;
}
