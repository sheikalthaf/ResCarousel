import {
  Directive,
  ContentChild,
  ElementRef,
  OnInit,
  AfterContentInit,
  Renderer2,
  forwardRef,
  ContentChildren,
  QueryList,
  Input
} from '@angular/core';
import { CollapseChildDirective } from './collapse-child.directive';
import { CollapseParentLinkDirective } from './collapse-parent-link.directive';
import {
  AnimationBuilder,
  style,
  animate,
  AnimationFactory,
  AnimationPlayer
} from '@angular/animations';

@Directive({
  selector: '[appCollapseParent]'
})
export class CollapseParentDirective implements AfterContentInit {
  child: any;
  isAnimating: boolean;
  id: any;
  player: AnimationPlayer;
  constructor(private renderer: Renderer2, public builder: AnimationBuilder) {}
  // tslint:disable-next-line:no-input-rename
  @Input('collapse') coll: boolean;

  @ContentChild(CollapseChildDirective, { read: ElementRef })
  collapseChild: ElementRef;

  @ContentChildren(forwardRef(() => CollapseChildDirective))
  groups: QueryList<CollapseChildDirective>;

  @ContentChild(CollapseParentLinkDirective, { read: ElementRef })
  parentLink: ElementRef;

  ngAfterContentInit() {
    this.child = this.collapseChild.nativeElement;
    // console.log(this.collapseChild);
    this.renderer.setStyle(this.child, 'transistion', '.3s ease all');
    this.renderer.listen(this.parentLink.nativeElement, 'click', () => {
      if (this.child.classList.contains('active')) {
        // this.player.finish();
        this.renderer.removeClass(this.child, 'active');
        // this.renderer.setStyle(this.child, 'display', '0');
        // this.renderer.setStyle(this.child, 'max-height', '0');
        this.animateChilds(1);
        // const hei = this.child.clientHeight;
        // console.log(hei);
      } else {
        this.renderer.addClass(this.child, 'active');
        this.animateChilds(0);
        // this.renderer.setStyle(this.child, 'max-height', '');
        // this.animate(1);
      }
      // }
    });
    // console.log(this.groups);
    console.log(this.groups);
    console.log(this.collapseChild);
  }

  animateChilds(id) {
    this.renderer.setAttribute(this.child, 'style', '');
    const hei = this.child.scrollHeight;
    // console.log(hei);
    if (id === 0) {
      // console.log('close');
      // console.log(`${hei}px`);
      this.renderer.setStyle(this.child, 'height', `${hei}px`);
      setTimeout(() => {
        this.renderer.setStyle(this.child, 'height', `0px`);
        this.renderer.setStyle(this.child, 'transform', `scale(.9)`);
        this.renderer.addClass(this.child, 'activeCollapse');
      }, 10);
    } else {
      this.renderer.addClass(this.child, 'activeCollapse');
      // console.log('open');
      this.renderer.setStyle(this.child, 'transform', `scale(.5)`);
      setTimeout(() => {
        this.renderer.setStyle(this.child, 'transform', `scale(1)`);
        this.renderer.setStyle(this.child, 'height', `${hei}px`);
      }, 10);
    }
    setTimeout(() => {
      this.renderer.removeClass(this.child, 'activeCollapse');
      this.renderer.setAttribute(this.child, 'style', '');
      // this.renderer.setStyle(this.child, 'height', '');
      // this.renderer.setStyle(this.child, 'transform', '');
      if (id === 0) {
        this.renderer.setStyle(this.child, 'display', 'none');
      }
    }, 300);
  }

  animate(id) {
    let factory: AnimationFactory;
    this.id = id;
    const hei = this.child.clientHeight;
    console.log(hei);
    if (id) {
      // console.log(hei);
      // this makes instructions on how to build the animation
      factory = this.builder.build([
        // the animation
        style({
          width: '*',
          display: 'block',
          position: 'relative',
          height: hei
        }),
        animate('350ms ease', style({ height: '0px' }))
      ]);
      // console.log('pla');
    } else {
      factory = this.builder.build([
        // the animation
        style({
          width: '*',
          display: 'block',
          position: 'relative',
          height: '0px'
        }),
        animate(
          '350ms cubic-bezier(.35, 0, .25, 1)',
          style({ height: hei + 'px' })
        )
      ]);
    }

    // this creates the animation
    this.player = factory.create(this.child);
    // player.finish();

    // start it off
    this.player.play();
    this.player.onStart(() => {
      this.isAnimating = true;
    });
    this.player.onDone(() => {
      console.log('completed');
      this.isAnimating = false;
      if (this.id !== 0) {
        this.renderer.setStyle(this.child, 'display', 'none');
        this.renderer.setStyle(this.child, 'height', 'auto');
      } else {
        this.renderer.setStyle(this.child, 'display', 'block');
        this.renderer.setStyle(this.child, 'height', 'auto');
      }
    });
    //   if (this.id) {
    //     this.renderer.setStyle(
    //       this.child,
    //       'display',
    //       'none'
    //     );
    //     this.renderer.setStyle(
    //       this.child,
    //       'position',
    //       'relative'
    //     );
    //     this.renderer.setStyle(
    //       this.child,
    //       'position',
    //       'relative'
    //     );
    //   } else {
    //     this.renderer.setStyle(
    //       this.child,
    //       'display',
    //       'block'
    //     );
    //   }
    // });
    console.log('player');
  }
}
