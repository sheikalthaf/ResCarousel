import { Directive } from '@angular/core';

@Directive({
  selector: '[appCollapseChild]'
})
export class CollapseChildDirective {

  constructor() { }

}
