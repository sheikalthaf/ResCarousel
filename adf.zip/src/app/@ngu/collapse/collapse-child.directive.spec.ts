import { CollapseChildDirective } from './collapse-child.directive';

describe('CollapseChildDirective', () => {
  it('should create an instance', () => {
    const directive = new CollapseChildDirective();
    expect(directive).toBeTruthy();
  });
});
