import { Directive } from '@angular/core';

@Directive({
  selector: '[appCollapseParentLink]'
})
export class CollapseParentLinkDirective {

  constructor() { }

}
