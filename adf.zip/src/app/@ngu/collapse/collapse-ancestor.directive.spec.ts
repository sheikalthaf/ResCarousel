import { CollapseAncestorDirective } from './collapse-ancestor.directive';

describe('CollapseAncestorDirective', () => {
  it('should create an instance', () => {
    const directive = new CollapseAncestorDirective();
    expect(directive).toBeTruthy();
  });
});
