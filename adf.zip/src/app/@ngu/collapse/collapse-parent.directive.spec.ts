import { CollapseParentDirective } from './collapse-parent.directive';

describe('CollapseParentDirective', () => {
  it('should create an instance', () => {
    const directive = new CollapseParentDirective();
    expect(directive).toBeTruthy();
  });
});
