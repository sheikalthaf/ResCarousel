import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CollapseParentDirective } from './collapse-parent.directive';
import { CollapseChildDirective } from './collapse-child.directive';
import { CollapseAncestorDirective } from './collapse-ancestor.directive';
import { CollapseParentLinkDirective } from './collapse-parent-link.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [
    CollapseParentDirective,
    CollapseChildDirective,
    CollapseAncestorDirective,
    CollapseParentLinkDirective
  ],
  exports: [
    CollapseParentDirective,
    CollapseChildDirective,
    CollapseAncestorDirective,
    CollapseParentLinkDirective
  ]
})
export class NguCollapseModule {}
