import {
  Directive,
  ContentChild,
  ElementRef,
  OnInit,
  AfterContentInit,
  Input,
  ContentChildren,
  QueryList,
  Renderer2,
  AfterContentChecked
} from '@angular/core';
import { CollapseParentDirective } from './collapse-parent.directive';
import { NguCollapse } from './ngu-collapse';
import { CollapseChildDirective } from './collapse-child.directive';

@Directive({
  selector: '[appCollapseAncestor]'
})
export class CollapseAncestorDirective
  implements OnInit, AfterContentInit, AfterContentChecked {
  @Input('config') config: NguCollapse;
  @ContentChildren(CollapseChildDirective, { read: ElementRef })
  collapseChild: QueryList<CollapseChildDirective>;

  constructor(private renderer: Renderer2) {}

  ngOnInit() {}

  ngAfterContentInit() {}
  ngAfterContentChecked() {
    // console.log(this.collapseChild);
    this.collapseChild.forEach((elem: ElementRef) => {
      console.log(elem);
      if (this.config.collapse === 'collapse') {
        this.renderer.addClass(elem.nativeElement, 'active');
        this.renderer.setStyle(elem.nativeElement, 'max-height', '0');
      } else if (this.config.collapse === 'uncollapse') {
        this.renderer.removeClass(elem.nativeElement, 'active');
        this.renderer.setStyle(elem.nativeElement, 'max-height', '');
      }
    });
  }
}
