import { CollapseParentLinkDirective } from './collapse-parent-link.directive';

describe('CollapseParentLinkDirective', () => {
  it('should create an instance', () => {
    const directive = new CollapseParentLinkDirective();
    expect(directive).toBeTruthy();
  });
});
