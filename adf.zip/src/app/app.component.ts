import { Component } from '@angular/core';
import { NguAlertService, NguAlert } from '@ngu/alert';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  datas: NguAlert;
  constructor(private alert: NguAlertService) {}

  openAlert() {
    let tim = 0;
    for (let i = 0; i < 20; i++) {
      setTimeout(() => {
        this.alert.open({
          heading: 'This is a heading',
          msg: 'This is a message from alert',
          type: 'success',
          duration: 1000
        });
      }, tim += 100);
    }
  }


}
